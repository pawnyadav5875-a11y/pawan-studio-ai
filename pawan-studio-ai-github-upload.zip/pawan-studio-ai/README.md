---
title: Pawan Studio AI
emoji: 🎨
colorFrom: purple
colorTo: blue
sdk: docker
app_port: 7860
pinned: false
---

# Pawan Studio AI

A responsive browser-first creative studio:
- Background removal with `@imgly/background-removal` (model assets download on first use).
- Brush-mask object cleanup with local diffusion-style inpainting. This is a classical approximation, not generative fill.
- Prompt-to-image via the public Pollinations image endpoint.

## Deploy
Create a Hugging Face **Docker Space** (if your account supports it), then upload all repository files. The container listens on port 7860.

## Run locally
`pip install -r requirements.txt` then `python app.py`; open `http://localhost:7860`.

## Privacy
There is no image upload API in this Flask server. Background removal and eraser processing happen in the visitor's browser. The image-generation prompt is sent to Pollinations. Third-party CDN/model providers receive asset requests and have their own terms and privacy policies.

## Costs and limitations
Free-tier eligibility, sleep, quotas and hardware are controlled by each provider and can change. Pollinations availability/rate limits can change. The inpainting tool is approximate and may leave artifacts. Check IMG.LY licensing before commercial use. Add only the exact `ads.txt` seller record supplied by your ad network using the `ADS_TXT_CONTENT` environment variable.
